from django.contrib import admin
from .models import noticePost
# Register your models here.

admin.site.register(noticePost)