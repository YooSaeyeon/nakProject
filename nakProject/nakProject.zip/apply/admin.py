from django.contrib import admin
from .models import apply
# Register your models here.
admin.site.register(apply)