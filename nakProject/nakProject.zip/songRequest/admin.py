from django.contrib import admin
from .models import sPost
# Register your models here.

admin.site.register(sPost)